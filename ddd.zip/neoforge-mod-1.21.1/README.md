# Minimal Anti-Cheat Mod for Minecraft 1.21.1 (NeoForge)

This is a lightweight anti-cheat mod designed to detect common cheats while maintaining minimal computational overhead.

## Features

- Speed hack detection
- Flight hack detection
- No-fall damage detection
- Reach distance detection
- Invulnerability detection
- Configurable check intervals to balance performance vs security
- Optimized algorithms to minimize server performance impact

## Configuration

The mod can be configured via the server config file:
- `check_interval_ticks`: How often to run checks (higher = less CPU usage, lower = more responsive)
- Individual toggles for each type of cheat detection

## Building

To build the mod:
1. Make sure you have Java 21 installed
2. Run: `./gradlew build` (Linux/Mac) or `gradlew.bat build` (Windows)
3. The built mod JAR will be in the `build/libs/` directory

## Performance Notes

This mod is specifically designed to use minimal computational resources:
- Checks only run at configured intervals rather than every tick
- Optimized algorithms avoid unnecessary calculations
- Position caching reduces repeated distance calculations
- Checks are skipped for creative mode players and other legitimate cases