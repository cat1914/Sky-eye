package com.example.mod;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.List;

/**
 * 反作弊命令处理器
 * 提供管理被禁止模组列表的命令
 */
@Mod.EventBusSubscriber(modid = MinimalAntiCheatMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class AntiCheatCommands {
    
    @SubscribeEvent
    public static void registerCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        
        dispatcher.register(Commands.literal("skyeye")
            .requires(source -> source.hasPermission(2)) // 需要管理员权限
            .then(Commands.literal("bannedmods")
                .then(Commands.literal("add")
                    .then(Commands.argument("modid", StringArgumentType.word())
                        .executes(context -> addBannedMod(
                            context.getSource(), 
                            StringArgumentType.getString(context, "modid")))))
                .then(Commands.literal("remove")
                    .then(Commands.argument("modid", StringArgumentType.word())
                        .executes(context -> removeBannedMod(
                            context.getSource(), 
                            StringArgumentType.getString(context, "modid")))))
                .then(Commands.literal("list")
                    .executes(context -> listBannedMods(context.getSource())))
                .then(Commands.literal("reload")
                    .executes(context -> reloadBannedMods(context.getSource())))));
    }
    
    private static int addBannedMod(CommandSourceStack source, String modId) {
        BannedModsManager.addBannedMod(modId);
        source.sendSuccess(() -> Component.translatable("minimal_anticheat.mod_added", modId), true);
        return 1;
    }
    
    private static int removeBannedMod(CommandSourceStack source, String modId) {
        BannedModsManager.removeBannedMod(modId);
        source.sendSuccess(() -> Component.translatable("minimal_anticheat.mod_removed", modId), true);
        return 1;
    }
    
    private static int listBannedMods(CommandSourceStack source) {
        List<String> bannedMods = BannedModsManager.getBannedModsList();
        if (bannedMods.isEmpty()) {
            source.sendSuccess(() -> Component.literal("没有被禁止的模组"), false);
        } else {
            String modList = String.join(", ", bannedMods);
            source.sendSuccess(() -> Component.literal("被禁止的模组列表: " + modList), false);
        }
        return 1;
    }
    
    private static int reloadBannedMods(CommandSourceStack source) {
        BannedModsManager.reload();
        source.sendSuccess(() -> Component.literal("已重新加载被禁止的模组列表"), true);
        return 1;
    }
}