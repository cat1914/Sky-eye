import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = MinimalAntiCheatMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.GAME)
public class AntiCheatHandler {
    // Cache last positions to reduce computation
    private static final Map<String, Vec3> lastPositions = new HashMap<>();
    private static final Map<String, Long> lastCheckTimes = new HashMap<>();

    // 内存完整性检查计数器
    private static int memoryIntegrityCheckCounter = 0;

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();

        // Only run checks every configured interval to reduce CPU usage
        if (player.getLevel().getGameTime() % Config.CHECK_INTERVAL_TICKS.get() != 0) {
            return;
        }

        // Perform various anti-cheat checks in a performance-optimized way
        performChecks(player);
        
        // 执行内存完整性检查，但频率更低以减少性能影响
        memoryIntegrityCheckCounter++;
        if (memoryIntegrityCheckCounter % 5 == 0) { // 每5次检查执行一次内存完整性检查
            performMemoryIntegrityCheck(player);
        }
    }

    private static void performChecks(Player player) {
        if (player.level().isClientSide()) {
            return; // Only run on server
        }

        String playerName = player.getName().getString();
        
        // Speed check
        if (Config.ENABLE_SPEED_CHECK.get()) {
            checkSpeed(player, playerName);
        }

        // Fly check
        if (Config.ENABLE_FLY_CHECK.get()) {
            checkFlight(player);
        }

        // No-fall check
        if (Config.ENABLE_NOFALL_CHECK.get()) {
            checkNoFall(player);
        }

        // Invulnerability check
        if (Config.ENABLE_INVULNERABILITY_CHECK.get()) {
            checkInvulnerability(player);
        }
    }
    
    private static void performMemoryIntegrityCheck(Player player) {
        // 仅在配置启用时执行内存完整性检查
        if (!Config.ENABLE_MEMORY_INTEGRITY_CHECK.get()) {
            return;
        }
        
        // 保护玩家健康值
        MemoryProtector.protectGameValue("player_health_" + player.getId(), player.getHealth());
        
        // 保护玩家位置
        Vec3 pos = player.position();
        MemoryProtector.protectGameValue("player_pos_" + player.getId(), 
            pos.x + "," + pos.y + "," + pos.z);
        
        // 保护玩家生命值
        MemoryProtector.protectGameValue("player_max_health_" + player.getId(), player.getMaxHealth());
        
        // 保护游戏时间
        MemoryProtector.protectGameValue("game_time", player.level().getGameTime());
        
        // 验证玩家健康值的完整性
        if (!MemoryProtector.verifyGameValue("player_health_" + player.getId(), player.getHealth())) {
            MemoryTamperHandler.handleMemoryTamper("PLAYER_HEALTH_INTEGRITY", 
                "Player: " + player.getName().getString() + ", Health: " + player.getHealth());
        }
        
        // 验证游戏时间的完整性
        if (!MemoryProtector.verifyGameValue("game_time", player.level().getGameTime())) {
            MemoryTamperHandler.handleMemoryTamper("GAME_TIME_INTEGRITY", 
                "Player: " + player.getName().getString() + ", GameTime: " + player.level().getGameTime());
        }
    }

    private static void checkSpeed(Player player, String playerName) {
        // Optimized speed detection that only calculates when necessary
        Vec3 currentPosition = player.position();
        Vec3 lastPosition = lastPositions.get(playerName);
        
        if (lastPosition != null) {
            // Calculate distance traveled since last check
            double distance = currentPosition.distanceTo(lastPosition);
            
            // Only check if player has moved significantly
            if (distance > 0.05) { // Minimum threshold to avoid checking tiny movements
                // Calculate speed based on time interval
                float maxSpeed = player.getAbilities().getWalkingSpeed() * 3.5F; // Allow sprinting + small buffer
                
                // Compare against expected max speed for the time interval
                if (distance > maxSpeed * Config.CHECK_INTERVAL_TICKS.get() / 20.0) {
                    // Before flagging as cheat, consider system metrics
                    if (SystemMetrics.isWindowsSystem()) {
                        // On Windows, allow for more leniency due to memory management patterns
                        if (distance > maxSpeed * Config.CHECK_INTERVAL_TICKS.get() / 20.0 * 1.2) { // 20% more lenient on Windows
                            MinimalAntiCheatMod.LOGGER.warn("Potential speed hack detected for player: " + playerName + 
                                " - Distance: " + distance + ", Max allowed: " + (maxSpeed * Config.CHECK_INTERVAL_TICKS.get() / 20.0 * 1.2) +
                                " (Note: This check is more lenient on Windows systems due to memory management patterns)");
                        }
                    } else {
                        MinimalAntiCheatMod.LOGGER.warn("Potential speed hack detected for player: " + playerName + 
                            " - Distance: " + distance + ", Max allowed: " + (maxSpeed * Config.CHECK_INTERVAL_TICKS.get() / 20.0));
                    }
                }
            }
        }
        
        // Update cached position
        lastPositions.put(playerName, currentPosition);
    }

    private static void checkFlight(Player player) {
        // Optimized flight detection
        if (player.getAbilities().flying || player.isSpectator() || player.isCreative()) {
            return; // Ignore if legitimately flying, spectator or creative
        }

        // Check if player is not on ground and not in water/lava
        if (!player.onGround() && 
            !player.isInWater() && 
            !player.isInLava() && 
            !player.isFallFlying() &&
            !player.hasEffect(net.minecraft.world.effect.MobEffects.SLOW_FALLING) &&
            !player.hasEffect(net.minecraft.world.effect.MobEffects.LEVITATION) &&
            player.getDeltaMovement().y >= 0) { // Only check upward movement
            
            // Double-check by testing if there's a block beneath the player
            BlockPos posBelow = player.blockPosition().below();
            if (!player.level().getBlockState(posBelow).blocksMotion()) {
                // Additional check: see if the player has been in air for a sustained period
                if (player.fallDistance < 0.5F) { // Not falling (negative fall distance means going up)
                    // Consider system metrics for Windows users
                    String warningMsg = "Potential fly hack detected for player: " + player.getName().getString();
                    if (SystemMetrics.isWindowsSystem()) {
                        warningMsg += " (Note: Windows memory management may affect client behavior)";
                    }
                    MinimalAntiCheatMod.LOGGER.warn(warningMsg);
                }
            }
        }
    }

    private static void checkNoFall(Player player) {
        // Check if player has taken a high fall but shows no damage
        if (player.fallDistance > 3.0F) {
            // If player is taking minimal damage from high fall, flag it
            // This check is now more precise to avoid false positives
            if (player.getHealth() >= player.getMaxHealth() - 1.0F && player.fallDistance > 5.0F) {
                String warningMsg = "Potential no-fall hack detected for player: " + player.getName().getString() + 
                    " - Fall distance: " + player.fallDistance + ", Health: " + player.getHealth();
                
                if (SystemMetrics.isWindowsSystem()) {
                    warningMsg += " (Note: Windows memory management may affect damage calculation)";
                }
                
                MinimalAntiCheatMod.LOGGER.warn(warningMsg);
            }
        }
    }

    private static void checkInvulnerability(Player player) {
        // Check for unusual health/invulnerability patterns
        // Increased threshold to reduce false positives
        if (player.invulnerableTime > 40) {
            String warningMsg = "Potential invulnerability hack detected for player: " + player.getName().getString() + 
                " - Invulnerable time: " + player.invulnerableTime;
            
            if (SystemMetrics.isWindowsSystem()) {
                warningMsg += " (Note: Windows memory management may cause timing variations)";
            }
            
            MinimalAntiCheatMod.LOGGER.warn(warningMsg);
        }
    }
}