package com.example.mod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import net.minecraft.network.chat.Component;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * 作弊模组列表管理器
 * 用于维护和管理禁止使用的模组列表
 */
public class BannedModsManager {
    private static final Logger LOGGER = LogManager.getLogger(BannedModsManager.class);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type LIST_TYPE = new TypeToken<List<String>>(){}.getType();
    
    private static List<String> bannedMods = new ArrayList<>();
    private static Path configPath;
    
    static {
        configPath = FMLPaths.CONFIGDIR.get().resolve("banned_mods.json");
        loadBannedModsList();
    }
    
    /**
     * 加载作弊模组列表
     */
    public static void loadBannedModsList() {
        try {
            if (Files.exists(configPath)) {
                String jsonContent = Files.readString(configPath);
                List<String> loadedList = GSON.fromJson(jsonContent, LIST_TYPE);
                if (loadedList != null) {
                    bannedMods = new ArrayList<>(loadedList);
                    LOGGER.info(Component.translatable("minimal_anticheat.mods_loaded", bannedMods.size()).getString());
                }
            } else {
                // 创建默认列表
                createDefaultBannedModsList();
            }
        } catch (Exception e) {
            LOGGER.error("加载被禁止模组列表失败: ", e);
            createDefaultBannedModsList(); // 加载失败时创建默认列表
        }
    }
    
    /**
     * 保存作弊模组列表
     */
    public static void saveBannedModsList() {
        try {
            String jsonContent = GSON.toJson(bannedMods, LIST_TYPE);
            Files.writeString(configPath, jsonContent);
        } catch (Exception e) {
            LOGGER.error("保存被禁止模组列表失败: ", e);
        }
    }
    
    /**
     * 创建默认的作弊模组列表
     */
    private static void createDefaultBannedModsList() {
        bannedMods = new ArrayList<>();
        // 添加一些常见的作弊模组作为示例
        bannedMods.add("feather"); // Feather client
        bannedMods.add("liquidbounce"); // LiquidBounce client
        bannedMods.add("novoline"); // Novoline client
        bannedMods.add("huzuni"); // Huzuni client
        bannedMods.add("geyser"); // Geyser (可能被滥用)
        bannedMods.add("optifine"); // OptiFine (可能包含作弊功能)
        bannedMods.add("malilib"); // May contain cheat modules
        bannedMods.add("fabric-external-gui"); // External GUI mod
        bannedMods.add("inventory-tweaks"); // Inventory tweaks (may include cheat features)
        bannedMods.add("xray-unity"); // X-ray mod
        saveBannedModsList();
        LOGGER.info(Component.translatable("minimal_anticheat.mods_loaded", bannedMods.size()).getString());
    }
    
    /**
     * 添加模组到黑名单
     */
    public static void addBannedMod(String modId) {
        if (!bannedMods.contains(modId.toLowerCase())) {
            bannedMods.add(modId.toLowerCase());
            saveBannedModsList();
            LOGGER.info(Component.translatable("minimal_anticheat.mod_added", modId).getString());
        }
    }
    
    /**
     * 从黑名单移除模组
     */
    public static void removeBannedMod(String modId) {
        if (bannedMods.remove(modId.toLowerCase())) {
            saveBannedModsList();
            LOGGER.info(Component.translatable("minimal_anticheat.mod_removed", modId).getString());
        }
    }
    
    /**
     * 检查模组是否在黑名单中
     */
    public static boolean isModBanned(String modId) {
        return bannedMods.contains(modId.toLowerCase());
    }
    
    /**
     * 获取当前被禁止的模组列表
     */
    public static List<String> getBannedModsList() {
        return new ArrayList<>(bannedMods);
    }
    
    /**
     * 批量检查多个模组
     */
    public static List<String> checkMultipleMods(List<String> modIds) {
        List<String> bannedModsFound = new ArrayList<>();
        for (String modId : modIds) {
            if (isModBanned(modId)) {
                bannedModsFound.add(modId);
            }
        }
        return bannedModsFound;
    }
    
    /**
     * 重新加载列表
     */
    public static void reload() {
        loadBannedModsList();
    }
}