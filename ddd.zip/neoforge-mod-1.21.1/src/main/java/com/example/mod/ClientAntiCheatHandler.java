import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = MinimalAntiCheatMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
@OnlyIn(Dist.CLIENT)
public class ClientAntiCheatHandler {
    
    private static final Map<String, Vec3> lastClientPositions = new HashMap<>();
    private static long lastClientCheckTick = 0;
    
    // Track key input patterns that might indicate macro/bot usage
    private static long lastKeyPressTime = 0;
    private static int keyPressCount = 0;
    private static long keyPressIntervalStart = 0;
    
    // 内存完整性检查计数器，减少性能影响
    private static int memoryIntegrityCheckCounter = 0;
    
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            return;
        }
        
        // Only run client-side checks periodically to reduce performance impact
        if (mc.level.getGameTime() % (Config.CHECK_INTERVAL_TICKS.get() * 2) != 0) {
            return;
        }
        
        performClientChecks(mc.player);
        
        // 定期执行内存完整性检查，但频率较低以减少性能影响
        memoryIntegrityCheckCounter++;
        if (memoryIntegrityCheckCounter % 10 == 0) { // 每10次客户端tick检查一次
            performMemoryIntegrityCheck(mc.player);
        }
    }
    
    private static void performClientChecks(LocalPlayer player) {
        // Client-side speed check
        if (Config.ENABLE_SPEED_CHECK.get()) {
            checkClientSpeed(player);
        }
        
        // Additional client-side checks can be added here
    }
    
    private static void checkClientSpeed(LocalPlayer player) {
        String playerName = player.getName().getString();
        Vec3 currentPosition = player.position();
        Vec3 lastPosition = lastClientPositions.get(playerName);
        
        if (lastPosition != null) {
            double distance = currentPosition.distanceTo(lastPosition);
            
            // Only check if player has moved significantly (avoid tiny movements)
            if (distance > 0.05) {
                // Calculate speed based on time interval
                float maxSpeed = player.getAbilities().getWalkingSpeed() * 4.0F; // Allow sprinting + small buffer
                
                // Compare against expected max speed for the time interval
                // Note: On client side, we're just doing basic validation to catch obvious client modifications
                if (distance > maxSpeed * Config.CHECK_INTERVAL_TICKS.get() / 20.0) {
                    // Instead of assuming cheat, send warning to server for proper validation
                    // This avoids false positives from legitimate client-side lag or Windows memory management
                    MinimalAntiCheatMod.LOGGER.warn("Potential speed anomaly detected locally for player: " + 
                        playerName + " - Distance: " + distance + 
                        " (This may be due to client-side lag, not necessarily cheating)");
                }
            }
        }
        
        // Update cached position
        lastClientPositions.put(playerName, currentPosition);
    }
    
    private static void performMemoryIntegrityCheck(LocalPlayer player) {
        // 仅在配置启用时执行内存完整性检查
        if (!Config.ENABLE_MEMORY_INTEGRITY_CHECK.get()) {
            return;
        }
        
        // 执行轻量级内存完整性检查
        // 保护玩家健康值
        MemoryProtector.protectGameValue("player_health_" + player.getId(), player.getHealth());
        
        // 保护玩家位置
        Vec3 pos = player.position();
        MemoryProtector.protectGameValue("player_pos_" + player.getId(), 
            pos.x + "," + pos.y + "," + pos.z);
        
        // 保护游戏时间（防止时间篡改）
        MemoryProtector.protectGameValue("game_time", player.level().getGameTime());
        
        // 在Windows系统上减少检查频率以避免内存管理干扰
        if (!SystemMetrics.isWindowsSystem() || System.currentTimeMillis() % 5000 < 100) {
            // 验证关键游戏数据的完整性
            if (!MemoryProtector.verifyGameValue("game_time", player.level().getGameTime())) {
                MemoryTamperHandler.handleMemoryTamper("CLIENT_GAME_TIME_INTEGRITY", 
                    "Player: " + player.getName().getString() + ", GameTime: " + player.level().getGameTime());
            }
        }
    }
    
    @SubscribeEvent
    public static void onMouseInput(InputEvent.MouseButton.Post event) {
        // Check for unusual input patterns that might indicate automation
        // But be careful not to flag legitimate Windows memory/paging behavior
        long currentTime = System.currentTimeMillis();
        
        if (keyPressIntervalStart == 0) {
            keyPressIntervalStart = currentTime;
        }
        
        // Reset counter if too much time has passed between inputs
        if (currentTime - lastKeyPressTime > 1000) { // 1 second
            keyPressCount = 0;
            keyPressIntervalStart = currentTime;
        }
        
        keyPressCount++;
        lastKeyPressTime = currentTime;
        
        // Check for extremely rapid inputs that might indicate automation
        // But allow for Windows' normal memory management patterns
        if (currentTime - keyPressIntervalStart < 1000 && keyPressCount > 50) { // More than 50 inputs in 1 second
            MinimalAntiCheatMod.LOGGER.warn("Unusual input pattern detected - possible automation, " +
                "but could also be normal system behavior: " + keyPressCount + " inputs in " + 
                (currentTime - keyPressIntervalStart) + "ms");
            // Reset to avoid spam
            keyPressCount = 0;
            keyPressIntervalStart = currentTime;
        }
    }
    
    public static void init() {
        // Client initialization
        MinimalAntiCheatMod.LOGGER.debug("Client Anti-Cheat Handler initialized");
        
        // 初始化时保护基本的客户端状态
        MemoryProtector.protectData("client_initialized", String.valueOf(System.currentTimeMillis()));
    }
}