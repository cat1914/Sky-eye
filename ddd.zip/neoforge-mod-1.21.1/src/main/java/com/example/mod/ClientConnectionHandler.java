package com.example.mod;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.fml.loading.FMLLoader;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 客户端事件处理器，处理连接服务器时的模组检查
 */
@Mod.EventBusSubscriber(modid = MinimalAntiCheatMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientConnectionHandler {
    
    /**
     * 在客户端连接到服务器时触发
     */
    @SubscribeEvent
    public static void onClientConnect(ClientPlayerNetworkEvent.LoggingIn event) {
        if (FMLLoader.getDist() == Dist.CLIENT) {
            // 仅在服务器启用模组检查时发送模组列表
            if (Config.ENABLE_MOD_CHECK_ON_CONNECT.get()) {
                // 获取客户端安装的模组列表
                List<String> modIds = ModList.get().getMods().stream()
                        .map(mod -> mod.getModId().toLowerCase())
                        .collect(Collectors.toList());
                
                MinimalAntiCheatMod.LOGGER.info("Sending mod list to server for checking, total {} mods", modIds.size());
                
                // 向服务器发送模组列表进行检查
                NetworkHandler.ModCheckRequest request = new NetworkHandler.ModCheckRequest(modIds);
                PacketDistributor.SERVER.noArg().send(request);
            }
        }
    }
    
    /**
     * 在客户端断开连接时触发
     */
    @SubscribeEvent
    public static void onClientDisconnect(ClientPlayerNetworkEvent.LoggingOut event) {
        // 可以在这里添加断开连接后的清理逻辑
        MinimalAntiCheatMod.LOGGER.info("客户端已断开连接");
    }
}