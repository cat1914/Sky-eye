import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.fml.common.Mod;

@OnlyIn(Dist.CLIENT)
public class ClientProxy {
    public static void init() {
        // Client-side initialization
        ClientAntiCheatHandler.init();
    }
}