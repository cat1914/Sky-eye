import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.common.Mod;

public class CommonProxy {
    public static void init() {
        // Register configuration
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, Config.getSpec());
        
        // Log system information at initialization
        SystemMetrics.logSystemInfo();
        
        // 初始化被禁止的模组列表
        BannedModsManager.loadBannedModsList();
    }
}