import net.neoforged.neoforge.common.ModConfigSpec;

public class Config {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
    private static final ModConfigSpec SPEC;

    // Performance settings
    public static final ModConfigSpec.IntValue CHECK_INTERVAL_TICKS;
    public static final ModConfigSpec.BooleanValue ENABLE_SPEED_CHECK;
    public static final ModConfigSpec.BooleanValue ENABLE_FLY_CHECK;
    public static final ModConfigSpec.BooleanValue ENABLE_NOFALL_CHECK;
    public static final ModConfigSpec.BooleanValue ENABLE_REACH_CHECK;
    public static final ModConfigSpec.BooleanValue ENABLE_INVULNERABILITY_CHECK;
    
    // Anti-cheat performance settings
    public static final ModConfigSpec.BooleanValue ENABLE_MOD_CHECK_ON_CONNECT;
    public static final ModConfigSpec.IntValue MOD_CHECK_DELAY_TICKS;
    public static final ModConfigSpec.BooleanValue ENABLE_MEMORY_INTEGRITY_CHECK;

    static {
        BUILDER.push("Performance Settings");

        CHECK_INTERVAL_TICKS = BUILDER
                .comment("Interval in ticks between anti-cheat checks (higher = less CPU usage)")
                .defineInRange("check_interval_ticks", 20, 1, 100);

        ENABLE_SPEED_CHECK = BUILDER
                .comment("Enable speed hack detection")
                .define("enable_speed_check", true);

        ENABLE_FLY_CHECK = BUILDER
                .comment("Enable flight hack detection")
                .define("enable_fly_check", true);

        ENABLE_NOFALL_CHECK = BUILDER
                .comment("Enable no-fall damage hack detection")
                .define("enable_nofall_check", true);

        ENABLE_REACH_CHECK = BUILDER
                .comment("Enable reach distance hack detection")
                .define("enable_reach_check", true);

        ENABLE_INVULNERABILITY_CHECK = BUILDER
                .comment("Enable invulnerability/health hack detection")
                .define("enable_invulnerability_check", true);

        BUILDER.pop();
        
        BUILDER.push("Anti-Cheat Server Settings");
        
        ENABLE_MOD_CHECK_ON_CONNECT = BUILDER
                .comment("Enable mod list checking when players connect to server")
                .define("enable_mod_check_on_connect", true);
                
        MOD_CHECK_DELAY_TICKS = BUILDER
                .comment("Delay in ticks before performing mod check after player connects (to avoid conflicts with other mods)")
                .defineInRange("mod_check_delay_ticks", 20, 0, 100);
                
        ENABLE_MEMORY_INTEGRITY_CHECK = BUILDER
                .comment("Enable memory integrity checks (may impact performance)")
                .define("enable_memory_integrity_check", false);

        BUILDER.pop();

        SPEC = BUILDER.build();
    }

    public static void init() {
        // Configuration initialization
    }

    public static ModConfigSpec getSpec() {
        return SPEC;
    }
}