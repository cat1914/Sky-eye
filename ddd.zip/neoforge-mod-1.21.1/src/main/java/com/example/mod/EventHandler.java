import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

@Mod.EventBusSubscriber(modid = MinimalAntiCheatMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.GAME)
public class EventHandler {
    
    @SubscribeEvent
    public static void onPlayerInteract(PlayerInteractEvent.RightClickBlock event) {
        Player player = event.getEntity();
        
        // Only run intensive checks occasionally to preserve performance
        if (player.level().getGameTime() % Config.CHECK_INTERVAL_TICKS.get() != 0) {
            return;
        }
        
        // Check for reach distance if enabled
        if (Config.ENABLE_REACH_CHECK.get()) {
            checkReachDistance(player, event.getPos().getCenter());
        }
    }
    
    private static void checkReachDistance(Player player, Vec3 targetPos) {
        // More accurate reach check using player's eye position
        Vec3 eyePos = player.getEyePosition();
        double reachDistance = eyePos.distanceToSqr(targetPos);
        
        // Standard MC reach is about 4.5 blocks for survival, 5.0 for creative
        double maxReach = player.isCreative() ? 5.0 : 4.5;
        double maxReachSqr = maxReach * maxReach;
        
        if (reachDistance > maxReachSqr) {
            String warningMsg = "Potential reach hack detected for player: " + player.getName().getString() + 
                " - Distance: " + Math.sqrt(reachDistance) + ", Max allowed: " + maxReach;
            
            if (SystemMetrics.isWindowsSystem()) {
                warningMsg += " (Note: Windows memory management may affect client behavior)";
            }
            
            MinimalAntiCheatMod.LOGGER.warn(warningMsg);
        }
    }
    
    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        Player player = event.getEntity();
        MinimalAntiCheatMod.LOGGER.info("Player logged in: " + player.getName().getString());
        
        // Log system metrics for Windows users on login
        if (SystemMetrics.isWindowsSystem()) {
            MinimalAntiCheatMod.LOGGER.info("Windows user detected: Adjusting anti-cheat sensitivity for " + player.getName().getString());
            SystemMetrics.logSystemInfo();
        }
    }
    
    @SubscribeEvent
    public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        MinimalAntiCheatMod.LOGGER.info("Player logged out: " + event.getEntity().getName().getString());
    }
}