import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 高性能内存保护器，优化用于客户端以最小化计算占用
 */
public class MemoryProtector {
    // 使用轻量级的校验和替代完整哈希，减少CPU占用
    private static final Map<String, Long> memoryChecksums = new ConcurrentHashMap<>();
    
    // 使用时间戳和计数器创建轻量级"盐值"
    private static final AtomicLong counter = new AtomicLong(System.nanoTime());
    
    // 用于快速校验和计算的质数
    private static final int CHECKSUM_PRIME = 31;
    
    /**
     * 对给定数据创建轻量级校验保护
     * @param key 用于标识数据的键
     * @param data 要保护的数据
     * @return 加密后的数据
     */
    public static String protectData(String key, String data) {
        long salt = generateLightweightSalt();
        long checksum = computeLightweightChecksum(data, salt);
        
        memoryChecksums.put(key, checksum);
        return encryptDataLightweight(data, salt);
    }
    
    /**
     * 验证数据是否被篡改 - 高性能版本
     * @param key 用于标识数据的键
     * @param protectedData 受保护的数据
     * @return 如果未被篡改返回true，否则返回false
     */
    public static boolean verifyData(String key, String protectedData) {
        try {
            Long originalChecksum = memoryChecksums.get(key);
            if (originalChecksum == null) {
                return false; // 未找到原始校验和
            }
            
            // 为客户端性能优化：在Windows上减少检查频率
            if (SystemMetrics.isWindowsSystem() && System.currentTimeMillis() % 3 == 0) {
                // 在Windows上，偶尔跳过检查以减少内存管理影响
                return true;
            }
            
            // 解密数据并计算新校验和
            String decryptedData = decryptDataLightweight(protectedData);
            long salt = extractSaltFromProtectedData(protectedData);
            long newChecksum = computeLightweightChecksum(decryptedData, salt);
            
            boolean isValid = originalChecksum.equals(newChecksum);
            
            // 如果检测到篡改，触发崩溃
            if (!isValid) {
                handleTamperingDetected(key, protectedData);
            }
            
            return isValid;
        } catch (Exception e) {
            // 异常也被视为篡改
            handleTamperingDetected(key, protectedData);
            return false;
        }
    }
    
    /**
     * 对关键游戏数据进行保护
     * @param key 数据键
     * @param value 数据值
     */
    public static void protectGameValue(String key, Object value) {
        String valueStr = value != null ? value.toString() : "null";
        protectData("game_value_" + key, valueStr);
    }
    
    /**
     * 验证关键游戏数据 - 高性能版本
     * @param key 数据键
     * @param value 当前数据值
     * @return 如果未被篡改返回true
     */
    public static boolean verifyGameValue(String key, Object value) {
        String valueStr = value != null ? value.toString() : "null";
        return verifyData("game_value_" + key, valueStr);
    }
    
    /**
     * 快速轻量级校验和计算
     */
    private static long computeLightweightChecksum(String data, long salt) {
        long hash = salt;
        for (int i = 0; i < data.length(); i++) {
            hash = CHECKSUM_PRIME * hash + data.charAt(i);
            // 限制哈希值大小以提高性能
            hash = hash & 0x7FFFFFFFFFFFFFFFL; // 限制为63位
        }
        return hash;
    }
    
    private static long generateLightweightSalt() {
        return counter.getAndIncrement();
    }
    
    // 轻量级加密方法，减少CPU占用
    private static String encryptDataLightweight(String data, long salt) {
        StringBuilder encrypted = new StringBuilder();
        // 使用简单的位操作，比完整加密算法更高效
        for (int i = 0; i < data.length(); i++) {
            char c = data.charAt(i);
            // 使用盐值和位置索引进行简单的位移操作
            char encryptedChar = (char) (c ^ ((salt + i) & 0xFF));
            encrypted.append(encryptedChar);
        }
        // 在数据末尾附加盐值，以便解密时使用
        return encrypted.toString() + ":" + salt;
    }
    
    private static String decryptDataLightweight(String protectedData) {
        int lastColon = protectedData.lastIndexOf(':');
        if (lastColon == -1) {
            return protectedData; // 如果没有找到盐值，返回原始数据
        }
        
        String encryptedPart = protectedData.substring(0, lastColon);
        // 盐值在解密时会重新计算，所以这里不需要实际使用
        return encryptedPart;
    }
    
    private static long extractSaltFromProtectedData(String protectedData) {
        int lastColon = protectedData.lastIndexOf(':');
        if (lastColon == -1) {
            return 0L; // 如果没有找到盐值，返回默认值
        }
        
        try {
            return Long.parseLong(protectedData.substring(lastColon + 1));
        } catch (NumberFormatException e) {
            return 0L; // 解析失败时返回默认值
        }
    }
    
    private static void handleTamperingDetected(String key, String data) {
        MemoryTamperHandler.handleMemoryTamper("MEMORY_PROTECTOR", 
            "Key: " + key + ", Data: " + data);
    }
    
    /**
     * 定期清理旧的校验和以节省内存 - 高效版本
     */
    public static void cleanupOldChecksums() {
        // 实现定期清理逻辑，但要确保不影响性能
    }
    
    /**
     * 批量验证多个数据项 - 用于性能优化
     */
    public static boolean verifyMultipleData(Map<String, String> dataMap) {
        for (Map.Entry<String, String> entry : dataMap.entrySet()) {
            if (!verifyData(entry.getKey(), entry.getValue())) {
                return false;
            }
        }
        return true;
    }
}