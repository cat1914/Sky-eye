import net.neoforged.fml.loading.FMLLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 处理内存篡改事件的专门类
 * 包含崩溃游戏的机制和日志记录
 */
public class MemoryTamperHandler {
    private static final Logger LOGGER = LogManager.getLogger(MemoryTamperHandler.class);
    
    /**
     * 处理检测到的内存篡改事件
     * 在实际应用中，这将导致游戏崩溃
     * 
     * @param detectionPoint 检测点描述
     * @param additionalInfo 额外信息
     */
    public static void handleMemoryTamper(String detectionPoint, String additionalInfo) {
        String errorMsg = String.format("CRITICAL ANTI-CHEAT VIOLATION at %s: Memory tampering detected! %s", 
            detectionPoint, additionalInfo != null ? additionalInfo : "");
        
        LOGGER.fatal(errorMsg);
        LOGGER.fatal("System Information:");
        LOGGER.fatal("- OS: " + System.getProperty("os.name"));
        LOGGER.fatal("- OS Version: " + System.getProperty("os.version"));
        LOGGER.fatal("- Java Version: " + System.getProperty("java.version"));
        LOGGER.fatal("- Memory Usage: " + SystemMetrics.getUsedMemory() / (1024 * 1024) + "MB/" + 
                     SystemMetrics.getMaxMemory() / (1024 * 1024) + "MB");
        LOGGER.fatal("- Is Windows: " + SystemMetrics.isWindowsSystem());
        
        // 在开发模式下，我们只记录错误
        // 在生产环境中，这里会实际崩溃游戏以阻止作弊
        if (FMLLoader.isProduction()) {
            LOGGER.fatal("CRASHING GAME TO PREVENT CHEATING...");
            // 实际执行崩溃操作
            System.exit(-1);
        } else {
            LOGGER.warn("In development mode - not crashing game, but memory tampering detected!");
        }
    }
    
    /**
     * 验证内存完整性并处理篡改
     * 
     * @param key 内存位置键
     * @param data 要验证的数据
     * @return 如果未篡改返回true
     */
    public static boolean verifyAndHandle(String key, String data) {
        boolean isValid = MemoryProtector.verifyData(key, data);
        if (!isValid) {
            handleMemoryTamper("MEMORY_INTEGRITY_CHECK", "Key: " + key + ", Data: " + data);
        }
        return isValid;
    }
}