import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.loading.FMLLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import net.minecraft.network.chat.Component;

@Mod(MinimalAntiCheatMod.MOD_ID)
public class MinimalAntiCheatMod {
    public static final String MOD_ID = "minimal_anticheat";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public MinimalAntiCheatMod(IEventBus modEventBus) {
        LOGGER.info(Component.translatable("minimal_anticheat.loading").getString());

        // 初始化模组配置
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, Config.getSpec());
        
        // 初始化网络处理器
        modEventBus.addListener(NetworkHandler::registerPayloadHandlers);
        
        // 初始化代理
        if (FMLLoader.getDist() == Dist.CLIENT) {
            modEventBus.addListener(ClientProxy::init);
        }
        
        CommonProxy.init();
    }
}