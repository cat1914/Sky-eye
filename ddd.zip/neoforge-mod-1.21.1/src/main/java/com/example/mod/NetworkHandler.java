package com.example.mod;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.network.ChannelBuilder;
import net.neoforged.neoforge.network.registration.IPayloadRegistrar;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.client.Minecraft;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.registries.ModRegistry;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 网络处理类，用于处理客户端和服务器之间的交互
 */
@Mod.EventBusSubscriber(modid = MinimalAntiCheatMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class NetworkHandler {
    
    public static final String PROTOCOL_VERSION = "1";
    public static IPayloadRegistrar INSTANCE;
    
    @SubscribeEvent
    public static void registerPayloadHandlers(RegisterPayloadHandlersEvent event) {
        INSTANCE = event.registrar(MinimalAntiCheatMod.MOD_ID)
                .versioned(PROTOCOL_VERSION);
                
        INSTANCE.playBidirectional(
            ResourceLocation.fromNamespaceAndPath(MinimalAntiCheatMod.MOD_ID, "mod_check_request"),
            ModCheckRequest::read,
            ModCheckRequest::write,
            ModCheckRequest::handle
        );
        
        INSTANCE.playBidirectional(
            ResourceLocation.fromNamespaceAndPath(MinimalAntiCheatMod.MOD_ID, "mod_check_response"),
            ModCheckResponse::read,
            ModCheckResponse::write,
            ModCheckResponse::handle
        );
    }
    
    /**
     * 客户端向服务器发送模组列表的请求包
     */
    public static class ModCheckRequest {
        private final List<String> modList;
        
        public ModCheckRequest(List<String> modList) {
            this.modList = new ArrayList<>(modList);
        }
        
        public void write(FriendlyByteBuf buffer) {
            buffer.writeCollection(this.modList, FriendlyByteBuf::writeUtf);
        }
        
        public static ModCheckRequest read(FriendlyByteBuf buffer) {
            List<String> modList = buffer.readList(FriendlyByteBuf::readUtf);
            return new ModCheckRequest(modList);
        }
        
        public static void handle(ModCheckRequest payload, IPayloadContext context) {
            context.enqueueWork(() -> {
                ServerPlayer player = (ServerPlayer) context.player();
                
                // 检查是否启用了模组检查
                if (!Config.ENABLE_MOD_CHECK_ON_CONNECT.get()) {
                    // 如果未启用模组检查，则允许连接
                    ModCheckResponse response = new ModCheckResponse(true, Component.translatable("minimal_anticheat.mod_check_allowed").getString(), new ArrayList<>());
                    net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(player, response);
                    return;
                }
                
                // 检查客户端发送的模组列表
                List<String> bannedModsFound = BannedModsManager.checkMultipleMods(payload.modList);
                
                if (!bannedModsFound.isEmpty()) {
                    // 发现被禁止的模组，断开客户端连接
                    String message = Component.translatable("minimal_anticheat.banned_mods_detected", String.join(", ", bannedModsFound)).getString();
                    MinimalAntiCheatMod.LOGGER.warn("玩家 {} 连接被拒绝 - {}", player.getName().getString(), message);
                    
                    // 发送包含错误信息的响应
                    ModCheckResponse response = new ModCheckResponse(false, message, bannedModsFound);
                    net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(player, response);
                    
                    // 断开客户端连接
                    player.connection.disconnect(Component.translatable("minimal_anticheat.connection_denied", String.join(", ", bannedModsFound)));
                } else {
                    // 模组列表中没有被禁止的模组，允许连接
                    String passMessage = Component.translatable("minimal_anticheat.player_mods_checked", player.getName().getString()).getString();
                    MinimalAntiCheatMod.LOGGER.info(passMessage);
                    
                    ModCheckResponse response = new ModCheckResponse(true, Component.translatable("minimal_anticheat.mod_check_allowed").getString(), new ArrayList<>());
                    net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(player, response);
                }
            });
        }
    }
    
    /**
     * 服务器向客户端发送检查结果的响应包
     */
    public static class ModCheckResponse {
        private final boolean allowed;
        private final String message;
        private final List<String> bannedMods;
        
        public ModCheckResponse(boolean allowed, String message, List<String> bannedMods) {
            this.allowed = allowed;
            this.message = message;
            this.bannedMods = new ArrayList<>(bannedMods);
        }
        
        public void write(FriendlyByteBuf buffer) {
            buffer.writeBoolean(this.allowed);
            buffer.writeUtf(this.message);
            buffer.writeCollection(this.bannedMods, FriendlyByteBuf::writeUtf);
        }
        
        public static ModCheckResponse read(FriendlyByteBuf buffer) {
            boolean allowed = buffer.readBoolean();
            String message = buffer.readUtf(32767); // 最大消息长度
            List<String> bannedMods = buffer.readList(FriendlyByteBuf::readUtf);
            return new ModCheckResponse(allowed, message, bannedMods);
        }
        
        public static void handle(ModCheckResponse payload, IPayloadContext context) {
            context.enqueueWork(() -> {
                if (payload.allowed) {
                    MinimalAntiCheatMod.LOGGER.info(Component.translatable("minimal_anticheat.mod_check_allowed").getString() + ": {}", payload.message);
                } else {
                    MinimalAntiCheatMod.LOGGER.error(Component.translatable("minimal_anticheat.mod_check_denied", payload.message).getString());
                    // 在客户端显示警告信息
                    if (Minecraft.getInstance().player != null) {
                        Minecraft.getInstance().player.displayClientMessage(
                            Component.translatable("minimal_anticheat.connection_denied", payload.message), false);
                    }
                }
            });
        }
    }
}