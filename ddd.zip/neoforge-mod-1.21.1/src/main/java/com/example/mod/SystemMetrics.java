import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SystemMetrics {
    private static final Logger LOGGER = LogManager.getLogger("SystemMetrics");
    
    /**
     * 检测当前系统是否为Windows，因为Windows有特殊的内存管理特性
     * 这些特性不应被误判为作弊行为
     */
    public static boolean isWindowsSystem() {
        String osName = System.getProperty("os.name");
        return osName != null && osName.toLowerCase().contains("windows");
    }
    
    /**
     * 获取当前内存使用情况
     */
    public static long getUsedMemory() {
        Runtime runtime = Runtime.getRuntime();
        return runtime.totalMemory() - runtime.freeMemory();
    }
    
    /**
     * 获取最大可用内存
     */
    public static long getMaxMemory() {
        return Runtime.getRuntime().maxMemory();
    }
    
    /**
     * 获取内存使用百分比
     */
    public static double getMemoryUsagePercentage() {
        long maxMemory = getMaxMemory();
        if (maxMemory <= 0) return 0.0;
        
        long usedMemory = getUsedMemory();
        return (double) usedMemory / maxMemory * 100.0;
    }
    
    /**
     * 检查内存使用是否在合理范围内，避免将正常的Windows内存管理误判为异常行为
     */
    public static boolean isMemoryUsageNormal() {
        double memoryUsage = getMemoryUsagePercentage();
        
        // 在Windows上，内存使用率可能会因为系统内存管理策略而波动
        // 所以我们使用更宽松的阈值
        double threshold = isWindowsSystem() ? 95.0 : 90.0; // Windows阈值更高
        
        return memoryUsage < threshold;
    }
    
    /**
     * 记录系统信息，帮助识别正常的系统行为
     */
    public static void logSystemInfo() {
        LOGGER.info("Operating System: " + System.getProperty("os.name"));
        LOGGER.info("Memory - Used: " + getUsedMemory() / (1024 * 1024) + "MB, Max: " + getMaxMemory() / (1024 * 1024) + "MB, Usage: " + String.format("%.2f", getMemoryUsagePercentage()) + "%");
        LOGGER.info("Is Windows System: " + isWindowsSystem());
        
        if (isWindowsSystem()) {
            LOGGER.info("Note: Windows memory management may cause memory usage fluctuations - this is normal behavior");
        }
    }
}