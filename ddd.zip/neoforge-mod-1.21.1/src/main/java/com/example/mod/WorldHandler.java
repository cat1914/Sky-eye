import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.minecraft.world.level.Level;

@Mod.EventBusSubscriber(modid = MinimalAntiCheatMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.GAME)
public class WorldHandler {
    
    // Server-wide tick handler for performance monitoring
    @SubscribeEvent
    public static void onWorldTick(LevelTickEvent.Post event) {
        Level level = event.getLevel();
        
        // Only run on server side and only occasionally to preserve performance
        if (level.isClientSide() || level.getGameTime() % (Config.CHECK_INTERVAL_TICKS.get() * 10) != 0) {
            return;
        }
        
        // Log performance metrics occasionally
        MinimalAntiCheatMod.LOGGER.debug("World tick performance check: " + level.players().size() + " players online");
    }
}