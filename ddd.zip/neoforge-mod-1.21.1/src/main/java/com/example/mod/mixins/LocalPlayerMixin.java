package com.example.mod.mixins;

import com.example.mod.MemoryProtector;
import com.example.mod.MinimalAntiCheatMod;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin extends Player {
    private int movementCheckCounter = 0;
    
    public LocalPlayerMixin() {
        super(null, null, new net.minecraft.world.entity.EntityDimensions(1.0f, 1.0f, true));
    }
    
    // 监控客户端玩家移动
    @Inject(method = "setPos(DDD)V", at = @At("HEAD"))
    private void onClientSetPos(double x, double y, double z, CallbackInfo ci) {
        // 为客户端玩家位置变化添加更频繁的检查
        movementCheckCounter++;
        
        // 每隔几次移动检查一次内存完整性，减少性能影响
        if (movementCheckCounter % 5 == 0) { // 每5次移动检查一次
            String posKey = "client_player_pos_" + System.identityHashCode(this);
            String posData = x + "," + y + "," + z + "," + level().getGameTime();
            
            if (!MemoryTamperHandler.verifyAndHandle(posKey, posData)) {
                ci.cancel(); // 取消设置位置
            }
            
            MemoryProtector.protectData(posKey, posData);
        }
    }
    
    // 监控客户端玩家速度变化
    @Inject(method = "tick", at = @At("HEAD"))
    private void onClientTick(CallbackInfo ci) {
        // 检查游戏时间是否被篡改
        if (level().getGameTime() % 20 == 0) { // 每秒检查一次
            String gameTimeKey = "client_gametime_" + System.identityHashCode(this);
            String gameTimeData = String.valueOf(level().getGameTime());
            
            if (!MemoryTamperHandler.verifyAndHandle(gameTimeKey, gameTimeData)) {
                ci.cancel(); // 取消tick
            }
            
            MemoryProtector.protectData(gameTimeKey, gameTimeData);
        }
    }
}